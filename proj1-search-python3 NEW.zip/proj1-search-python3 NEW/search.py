# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def iterativeDeepening(problem):
    fringe = util.Queue()
    # Initial limit
    limit = 10
    
    # Just keep looping until found solution
    while True:
        fringe.push((problem.getStartState(), []))
        explored = []
        # Starting depth is zero
        maxDepth = 0
        # Increase limit after each iteration (starting is limit 2)
        limit += 10
        while not fringe.isEmpty():

            # Keep digging current node
            state, actions = fringe.pop()


            """
            print("ths is new ", state)
            print(actions)
            """
            
            if problem.isGoalState(state):
                return actions
            
            # If reached max depth just don't expand the node
            if maxDepth < limit:
                if state not in explored:
                    explored.append(state)

                    for successor, action, stepCost in problem.getSuccessors(state):
                        print("PROBLEM", problem.getSuccessors(state))
                        if successor not in explored:
                            next_actions = actions + [action]
                            successor_node = (successor, next_actions)
                            fringe.push(successor_node)
                    # Increase depth by 1 i.e. a counter to know where our current depth is so we can track with limit        
                    maxDepth += 1
           
            
    
    
    """print("Start's successors:", problem.getSuccessors((3,3 )))
   
    print(problem.isGoalState((1,1)))
    print("Start ", problem.getStartState());
    """
    
    return []

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print("Start:", problem.getStartState())
    print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    print("Start's successors:", problem.getSuccessors(problem.getStartState()))
    """
    fringe = util.Stack()
    
    fringe.push((problem.getStartState(), []))
  
    
    explored = []

    while not fringe.isEmpty():

        state, actions = fringe.pop()


        
        if problem.isGoalState(state):
            return actions
            
        if state not in explored:
            explored.append(state)
            
            for successor, action, stepCost in problem.getSuccessors(state):

                if successor not in explored:
                    next_actions = actions + [action]
                    successor_node = (successor, next_actions)
                    fringe.push(successor_node)
    
    
    """print("Start's successors:", problem.getSuccessors((3,3 )))
   
    print(problem.isGoalState((1,1)))
    print("Start ", problem.getStartState());
    """
    
    return []


def breadthFirstSearch(problem):
    fringe = util.Queue()
    
    
    fringe.push((problem.getStartState(), []))

    
    explored = []

    while not fringe.isEmpty():

        state, actions = fringe.pop()

        
        
        if problem.isGoalState(state):
            return actions
            
        if state not in explored:
            explored.append(state)
            
            for successor, action, stepCost in problem.getSuccessors(state):
                
            
                if successor not in explored:
                    next_actions = actions + [action]
                    successor_node = (successor, next_actions)
                    fringe.push(successor_node)
    
    
    """print("Start's successors:", problem.getSuccessors((3,3 )))
   
    print(problem.isGoalState((1,1)))
    print("Start ", problem.getStartState());
    """
    
    return []
    
    util.raiseNotDefined()

def uniformCostSearch(problem):
    # Creating a priority queue
    fringe = util.PriorityQueue()
    # Setting initial node priority 
    fringe.push((problem.getStartState(), []), 1)
  
    # To keep track of visited nodes
    explored = []

    while not fringe.isEmpty():
        # Taking the strongest priority node first i.e. West or South First
        state, actions = fringe.pop()
        
        if problem.isGoalState(state):
            return actions
        
        # if not seen before just add it in the node
        if state not in explored:
            explored.append(state)
            
            # get all successors and iterate over them
            for successor, action, stepCost in problem.getSuccessors(state):
                #print("Successor is State is actions  ", successor, state, actions)
                # if current action on successor function is north or east set cost to 2 
                # it will be 1 otherwise 
                if action == "East" or action == "North":
                    stepCost = 2
               
                # if sucessor or path is not already checked 
                if successor not in explored:
                    next_actions = actions + [action]
                    successor_node = (successor, next_actions)
                    # Push the node after getting list of actions along with stepcost
                    fringe.push(successor_node, stepCost)
    
    
    """print("Start's successors:", problem.getSuccessors((3,3 )))
   
    print(problem.isGoalState((1,1)))
    print("Start ", problem.getStartState());
    """
    
    return []

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    pQueue = util.PriorityQueue()
    """
    pQueue.push(1, 2)
    pQueue.push(7, 1)
    pQueue.push(4, 0)
    
    print(pQueue.pop())
    print(pQueue.pop())
    print(pQueue.pop())
    """
    
    explored = []
    cstate = problem.getStartState()
    pQueue.push((cstate, []), heuristic(cstate, problem))
    #pQueue.push((cstate, []), util.manhattanDistance(cstate, problem.goal))
    
    
    while not pQueue.isEmpty():
        state, actions = pQueue.pop()
        
        if problem.isGoalState(state):
            return actions
        if state not in explored:
            explored.append(state)
        
        for successor, action, stepCost in problem.getSuccessors(state):
            if successor not in explored:
                next_actions = actions + [action]
                successor_node = (successor, next_actions)
                hvalue = heuristic(successor, problem)
                print(hvalue)
                pQueue.push(successor_node, len(actions) + hvalue )
                
    return []

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
its = iterativeDeepening
